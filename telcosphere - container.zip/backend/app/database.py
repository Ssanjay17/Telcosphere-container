"""
MongoDB connection layer for TelcoSphere.
Collections mirror Section 6 (Database Design - Core Tables) of the platform diagram:
customers, sim_cards, plans, usage_records, invoices, payments, complaints
"""
import os
from pymongo import MongoClient, ASCENDING

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "telcosphere")

client = MongoClient(MONGO_URI)
db = client[DB_NAME]

customers_col = db["customers"]
sim_cards_col = db["sim_cards"]
plans_col = db["plans"]
usage_records_col = db["usage_records"]
invoices_col = db["invoices"]
payments_col = db["payments"]
complaints_col = db["complaints"]
admins_col = db["admins"]


def init_indexes():
    """Create indexes matching the (PK)/(FK) relationships shown in the ER diagram."""
    customers_col.create_index([("mobile", ASCENDING)], unique=True)
    customers_col.create_index([("email", ASCENDING)])
    sim_cards_col.create_index([("customer_id", ASCENDING)])
    sim_cards_col.create_index([("sim_number", ASCENDING)], unique=True)
    usage_records_col.create_index([("customer_id", ASCENDING)])
    invoices_col.create_index([("customer_id", ASCENDING)])
    payments_col.create_index([("invoice_id", ASCENDING)])
    complaints_col.create_index([("customer_id", ASCENDING)])
    admins_col.create_index([("username", ASCENDING)], unique=True)


def ping():
    return client.admin.command("ping")
