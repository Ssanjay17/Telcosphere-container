"""
Fraud Detection & Monitoring (AI/ML) - Section 5 Key Feature.
Uses an Isolation Forest to flag anomalous usage patterns (e.g. sudden spikes
in data/voice/sms consumption that deviate from a customer's/segment's norm).
"""
import numpy as np
from sklearn.ensemble import IsolationForest

from ..database import usage_records_col


def _customer_feature_vector(customer_id: str):
    pipeline = [
        {"$match": {"customer_id": customer_id}},
        {"$group": {"_id": "$usage_type", "total": {"$sum": "$quantity"}, "events": {"$sum": 1}}},
    ]
    agg = {r["_id"]: r for r in usage_records_col.aggregate(pipeline)}
    return [
        agg.get("voice", {}).get("total", 0),
        agg.get("sms", {}).get("total", 0),
        agg.get("data", {}).get("total", 0),
        agg.get("voice", {}).get("events", 0) + agg.get("sms", {}).get("events", 0) + agg.get("data", {}).get("events", 0),
    ]


def check_fraud(customer_id: str):
    # Build a population of feature vectors across all customers with usage,
    # to give the isolation forest something to compare against.
    all_customer_ids = usage_records_col.distinct("customer_id")
    if len(all_customer_ids) < 5:
        return {
            "customer_id": customer_id,
            "is_anomalous": False,
            "message": "Not enough population data yet to run fraud detection reliably.",
        }

    X = np.array([_customer_feature_vector(cid) for cid in all_customer_ids])
    model = IsolationForest(contamination=0.1, random_state=42)
    model.fit(X)

    target_vec = np.array([_customer_feature_vector(customer_id)])
    prediction = model.predict(target_vec)[0]  # -1 = anomaly, 1 = normal
    score = model.decision_function(target_vec)[0]

    return {
        "customer_id": customer_id,
        "is_anomalous": bool(prediction == -1),
        "anomaly_score": round(float(score), 4),
        "feature_vector": {
            "voice_mins": float(target_vec[0][0]),
            "sms_count": float(target_vec[0][1]),
            "data_mb": float(target_vec[0][2]),
            "total_events": int(target_vec[0][3]),
        },
        "message": "Usage pattern flagged as unusual - recommend manual review" if prediction == -1
                    else "Usage pattern within normal range",
    }
