"""
Plan / Offer recommendation - Section 5: 'Offers, Discounts & Loyalty'.
Content-based recommender: represents each plan as a feature vector
(data/voice/sms/price) and the customer's actual usage as a vector,
then recommends the plan(s) with the closest cosine similarity to usage,
biased slightly toward plans that comfortably cover the customer's needs.
"""
import numpy as np
from bson import ObjectId

from ..database import plans_col, usage_records_col


def _cosine_sim(a, b):
    a, b = np.array(a, dtype=float), np.array(b, dtype=float)
    if np.linalg.norm(a) == 0 or np.linalg.norm(b) == 0:
        return 0.0
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))


def recommend_plan(customer_id: str, top_n: int = 3):
    pipeline = [
        {"$match": {"customer_id": customer_id}},
        {"$group": {"_id": "$usage_type", "total": {"$sum": "$quantity"}}},
    ]
    usage = {r["_id"]: r["total"] for r in usage_records_col.aggregate(pipeline)}
    usage_vec = [usage.get("voice", 0), usage.get("sms", 0), usage.get("data", 0)]

    plans = list(plans_col.find())
    if not plans:
        return {"customer_id": customer_id, "recommendations": [], "message": "No plans in catalog yet"}

    scored = []
    for p in plans:
        plan_vec = [p["voice_limit_mins"], p["sms_limit"], p["data_limit_gb"]]
        sim = _cosine_sim(usage_vec, plan_vec)
        covers_needs = all(pv >= uv for pv, uv in zip(plan_vec, usage_vec))
        score = sim + (0.15 if covers_needs else -0.1)
        scored.append((score, p))

    scored.sort(key=lambda x: x[0], reverse=True)
    top = scored[:top_n]

    return {
        "customer_id": customer_id,
        "usage_profile": {"voice_mins": usage_vec[0], "sms_count": usage_vec[1], "data_gb": usage_vec[2]},
        "recommendations": [
            {
                "plan_id": str(p["_id"]),
                "plan_name": p["plan_name"],
                "price": p["price"],
                "match_score": round(score, 3),
            }
            for score, p in top
        ],
    }
