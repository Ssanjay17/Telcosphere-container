"""
Real-time Usage Tracking + forecasting - Section 5 Key Feature.
Simple linear regression over a customer's chronological usage events to
project next-period consumption per usage type (data/voice/sms), which feeds
'Usage Alerts & Notifications' and capacity planning.
"""
import numpy as np
from sklearn.linear_model import LinearRegression

from ..database import usage_records_col


def forecast_usage(customer_id: str, usage_type: str = "data"):
    records = list(
        usage_records_col.find({"customer_id": customer_id, "usage_type": usage_type}).sort("event_time", 1)
    )
    if len(records) < 3:
        return {
            "customer_id": customer_id,
            "usage_type": usage_type,
            "message": "Not enough historical events to forecast (need at least 3).",
        }

    X = np.arange(len(records)).reshape(-1, 1)
    y = np.array([r["quantity"] for r in records])
    cum_y = np.cumsum(y)

    model = LinearRegression()
    model.fit(X, cum_y)

    next_index = np.array([[len(records) + 5]])  # project 5 events ahead
    projected_cumulative = model.predict(next_index)[0]
    projected_next_period = max(0, projected_cumulative - cum_y[-1])

    return {
        "customer_id": customer_id,
        "usage_type": usage_type,
        "events_analyzed": len(records),
        "current_total": round(float(cum_y[-1]), 2),
        "projected_next_period_usage": round(float(projected_next_period), 2),
        "trend": "increasing" if model.coef_[0] > 0 else "decreasing",
    }
