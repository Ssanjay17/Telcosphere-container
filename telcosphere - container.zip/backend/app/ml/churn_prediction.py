"""
Retention & Offers (Business Process 9) / churn risk scoring.
A lightweight RandomForest trained on synthetic-but-plausible telecom churn
features: tenure, avg monthly usage, complaint count, invoice-payment delays.
In production this would train on historical labeled churn data pulled from
the Data Layer (PostgreSQL/ClickHouse); here we bootstrap a reasonable model
so the endpoint is usable out of the box.
"""
import numpy as np
from sklearn.ensemble import RandomForestClassifier

from ..database import customers_col, usage_records_col, complaints_col, invoices_col


def _train_synthetic_model():
    rng = np.random.RandomState(42)
    n = 500
    tenure_months = rng.randint(1, 60, n)
    avg_usage = rng.uniform(0, 100, n)
    complaint_count = rng.poisson(1.2, n)
    late_payments = rng.poisson(0.8, n)

    # heuristic churn label: low tenure + low usage + many complaints/late payments -> more likely churn
    churn_score = (
        (60 - tenure_months) * 0.02
        + (100 - avg_usage) * 0.01
        + complaint_count * 0.15
        + late_payments * 0.2
        + rng.normal(0, 0.3, n)
    )
    y = (churn_score > np.percentile(churn_score, 70)).astype(int)
    X = np.column_stack([tenure_months, avg_usage, complaint_count, late_payments])

    model = RandomForestClassifier(n_estimators=150, max_depth=6, random_state=42)
    model.fit(X, y)
    return model


_MODEL = _train_synthetic_model()


def predict_churn(customer_id: str):
    customer = customers_col.find_one({"_id": __import__("bson").ObjectId(customer_id)})
    if not customer:
        return {"error": "customer not found"}

    tenure_months = max(1, (__import__("datetime").datetime.utcnow() - customer["created_at"]).days // 30)

    usage_pipeline = [{"$match": {"customer_id": customer_id}}, {"$group": {"_id": None, "total": {"$sum": "$quantity"}}}]
    usage_agg = list(usage_records_col.aggregate(usage_pipeline))
    avg_usage = usage_agg[0]["total"] if usage_agg else 0

    complaint_count = complaints_col.count_documents({"customer_id": customer_id})
    late_payments = invoices_col.count_documents({"customer_id": customer_id, "status": "unpaid"})

    X = np.array([[tenure_months, avg_usage, complaint_count, late_payments]])
    proba = _MODEL.predict_proba(X)[0][1]

    risk = "high" if proba > 0.66 else "medium" if proba > 0.33 else "low"
    return {
        "customer_id": customer_id,
        "churn_probability": round(float(proba), 3),
        "risk_level": risk,
        "signals": {
            "tenure_months": tenure_months,
            "total_usage": avg_usage,
            "complaint_count": complaint_count,
            "unpaid_invoices": late_payments,
        },
        "recommended_action": "Offer retention discount / loyalty upgrade" if risk != "low" else "No action needed",
    }
