"""
Seeds the database with sample plans, customers (with KYC verified + activated
plans) and simulated usage events, so the dashboard / ML endpoints have data
to work with immediately. Run with: python -m app.seed_data
"""
import random
from datetime import datetime, timedelta
from faker import Faker

from .database import customers_col, plans_col, sim_cards_col, usage_records_col, init_indexes

fake = Faker()

SAMPLE_PLANS = [
    {"plan_name": "Unlimited 5G", "type": "postpaid", "price": 999, "data_limit_gb": 100, "voice_limit_mins": 1000, "sms_limit": 500, "validity_days": 30},
    {"plan_name": "Data Booster", "type": "prepaid", "price": 349, "data_limit_gb": 50, "voice_limit_mins": 300, "sms_limit": 100, "validity_days": 28},
    {"plan_name": "Talktime Pack", "type": "prepaid", "price": 199, "data_limit_gb": 5, "voice_limit_mins": 1500, "sms_limit": 300, "validity_days": 28},
    {"plan_name": "Basic Saver", "type": "prepaid", "price": 99, "data_limit_gb": 2, "voice_limit_mins": 200, "sms_limit": 50, "validity_days": 21},
]


def run():
    init_indexes()
    print("Seeding plans...")
    plan_ids = []
    for p in SAMPLE_PLANS:
        p = dict(p)
        p["created_at"] = datetime.utcnow()
        existing = plans_col.find_one({"plan_name": p["plan_name"]})
        if existing:
            plan_ids.append(existing["_id"])
            continue
        result = plans_col.insert_one(p)
        plan_ids.append(result.inserted_id)

    print("Seeding customers + usage...")
    for i in range(25):
        mobile = f"9{random.randint(100000000, 999999999)}"
        if customers_col.find_one({"mobile": mobile}):
            continue
        plan_id = random.choice(plan_ids)
        customer = {
            "name": fake.name(),
            "mobile": mobile,
            "email": fake.email(),
            "dob": str(fake.date_of_birth(minimum_age=18, maximum_age=65)),
            "address": fake.address(),
            "kyc_document_id": fake.ssn(),
            "kyc_status": "verified",
            "created_at": datetime.utcnow() - timedelta(days=random.randint(1, 500)),
            "plan_id": str(plan_id),
            "status": random.choice(["active", "active", "active", "suspended"]),
        }
        cust_result = customers_col.insert_one(customer)
        customer_id = str(cust_result.inserted_id)

        sim_cards_col.insert_one({
            "customer_id": customer_id,
            "plan_id": str(plan_id),
            "sim_number": mobile,
            "iccid": fake.numerify("89##################"),
            "status": "active",
            "activation_date": customer["created_at"],
            "validity_end": datetime.utcnow() + timedelta(days=30),
        })

        for _ in range(random.randint(5, 20)):
            usage_type = random.choice(["voice", "sms", "data"])
            qty = {
                "voice": random.uniform(1, 30),
                "sms": random.randint(1, 5),
                "data": random.uniform(50, 2000),
            }[usage_type]
            usage_records_col.insert_one({
                "customer_id": customer_id,
                "usage_type": usage_type,
                "quantity": qty,
                "event_time": datetime.utcnow() - timedelta(hours=random.randint(0, 240)),
                "source": "network",
                "chargeable": True,
            })

    print("Seeding complete.")


if __name__ == "__main__":
    run()
