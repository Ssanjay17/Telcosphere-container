from fastapi import APIRouter, HTTPException
from datetime import datetime
from bson import ObjectId

from ..database import payments_col, invoices_col
from ..models import PaymentRequest

router = APIRouter(prefix="/payments", tags=["6. Payment"])


def serialize(doc):
    doc["id"] = str(doc.pop("_id"))
    return doc


@router.post("")
def make_payment(payload: PaymentRequest):
    """Step 6 of Business Flow: customer pays bill through multiple channels
    (card / UPI / netbanking / wallet / Razorpay - mirrors External Systems: Payment Gateway)."""
    invoice = invoices_col.find_one({"_id": ObjectId(payload.invoice_id)})
    if not invoice:
        raise HTTPException(404, "Invoice not found")
    if invoice["status"] == "paid":
        raise HTTPException(400, "Invoice already paid")

    doc = {
        "invoice_id": payload.invoice_id,
        "customer_id": invoice["customer_id"],
        "amount": payload.amount,
        "method": payload.method,
        "status": "success" if abs(payload.amount - invoice["amount"]) < 0.01 else "partial",
        "transaction_id": f"TXN{ObjectId()}"[:18].upper(),
        "paid_at": datetime.utcnow(),
    }
    result = payments_col.insert_one(doc)
    doc["_id"] = result.inserted_id

    if doc["status"] == "success":
        invoices_col.update_one({"_id": ObjectId(payload.invoice_id)}, {"$set": {"status": "paid"}})

    return serialize(doc)


@router.get("/{customer_id}")
def list_payments(customer_id: str):
    return [serialize(p) for p in payments_col.find({"customer_id": customer_id}).sort("paid_at", -1)]
