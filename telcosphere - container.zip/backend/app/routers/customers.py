from fastapi import APIRouter, HTTPException
from datetime import datetime
from bson import ObjectId

from ..database import customers_col
from ..models import CustomerCreate, KYCVerify, StatusUpdate

router = APIRouter(prefix="/customers", tags=["1. Customer Onboarding & KYC"])


def serialize(doc):
    doc["id"] = str(doc.pop("_id"))
    return doc


@router.post("")
def register_customer(payload: CustomerCreate):
    """Step 1 of Business Flow: Customer Registration & KYC capture."""
    if customers_col.find_one({"mobile": payload.mobile}):
        raise HTTPException(400, "Customer with this mobile already exists")

    doc = payload.model_dump()
    doc.update({
        "kyc_status": "pending",
        "created_at": datetime.utcnow(),
        "plan_id": None,
        "status": "active",
    })
    result = customers_col.insert_one(doc)
    doc["_id"] = result.inserted_id
    return serialize(doc)


@router.get("")
def list_customers(limit: int = 50):
    return [serialize(c) for c in customers_col.find().sort("created_at", -1).limit(limit)]


@router.get("/{customer_id}")
def get_customer(customer_id: str):
    doc = customers_col.find_one({"_id": ObjectId(customer_id)})
    if not doc:
        raise HTTPException(404, "Customer not found")
    return serialize(doc)


@router.post("/{customer_id}/kyc")
def verify_kyc(customer_id: str, payload: KYCVerify):
    """KYC verification step - unlocks plan activation."""
    result = customers_col.update_one(
        {"_id": ObjectId(customer_id)},
        {"$set": {"kyc_status": payload.kyc_status}},
    )
    if result.matched_count == 0:
        raise HTTPException(404, "Customer not found")
    return {"customer_id": customer_id, "kyc_status": payload.kyc_status}


@router.post("/{customer_id}/status")
def update_status(customer_id: str, payload: StatusUpdate):
    """Activate or suspend a customer's SIM/account."""
    result = customers_col.update_one(
        {"_id": ObjectId(customer_id)},
        {"$set": {"status": payload.status}},
    )
    if result.matched_count == 0:
        raise HTTPException(404, "Customer not found")
    return {"customer_id": customer_id, "status": payload.status}
