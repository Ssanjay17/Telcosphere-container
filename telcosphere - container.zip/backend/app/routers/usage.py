from fastapi import APIRouter, HTTPException
from datetime import datetime
from bson import ObjectId

from ..database import usage_records_col, customers_col

router = APIRouter(prefix="/usage", tags=["3-4. Usage Generation & Processing"])


def serialize(doc):
    doc["id"] = str(doc.pop("_id"))
    return doc


@router.post("")
def record_usage(payload: dict):
    """
    Step 3-4 of Business Flow: Usage Generation (real-time CDR/event) &
    Usage Processing (aggregate voice/sms/data). Mirrors 'Real-Time Data Flow'
    (Network Elements -> Kafka -> Stream Processing -> Usage Store).
    """
    customer_id = payload.get("customer_id")
    if not customers_col.find_one({"_id": ObjectId(customer_id)}):
        raise HTTPException(404, "Customer not found")

    doc = {
        "customer_id": customer_id,
        "usage_type": payload["usage_type"],
        "quantity": payload["quantity"],
        "event_time": datetime.utcnow(),
        "source": payload.get("source", "network"),
        "chargeable": True,
    }
    result = usage_records_col.insert_one(doc)
    doc["_id"] = result.inserted_id
    return serialize(doc)


@router.get("/{customer_id}")
def get_usage(customer_id: str, limit: int = 100):
    records = list(
        usage_records_col.find({"customer_id": customer_id}).sort("event_time", -1).limit(limit)
    )
    return [serialize(r) for r in records]


@router.get("/{customer_id}/summary")
def usage_summary(customer_id: str):
    """Aggregate usage by type - powers 'Usage Alerts & Notifications' feature."""
    pipeline = [
        {"$match": {"customer_id": customer_id}},
        {"$group": {"_id": "$usage_type", "total": {"$sum": "$quantity"}, "events": {"$sum": 1}}},
    ]
    agg = {r["_id"]: {"total": r["total"], "events": r["events"]} for r in usage_records_col.aggregate(pipeline)}
    return agg
