from fastapi import APIRouter, HTTPException
from datetime import datetime, timedelta
from bson import ObjectId

from ..database import plans_col, customers_col, sim_cards_col
from ..models import PlanCreate, PlanActivate

router = APIRouter(prefix="/plans", tags=["2. Plan / Add-on Management"])


def serialize(doc):
    doc["id"] = str(doc.pop("_id"))
    return doc


@router.post("")
def create_plan(payload: PlanCreate):
    """Product Catalog management (Plans / Offers) - Microservices Layer."""
    doc = payload.model_dump()
    doc["created_at"] = datetime.utcnow()
    result = plans_col.insert_one(doc)
    doc["_id"] = result.inserted_id
    return serialize(doc)


@router.get("")
def list_plans():
    return [serialize(p) for p in plans_col.find()]


@router.post("/activate")
def activate_plan(payload: PlanActivate):
    """Step 2 of Business Flow: Plan Selection (Prepaid/Postpaid, Add-ons) & SIM Activation."""
    customer = customers_col.find_one({"_id": ObjectId(payload.customer_id)})
    if not customer:
        raise HTTPException(404, "Customer not found")
    if customer.get("kyc_status") != "verified":
        raise HTTPException(400, "Cannot activate plan: KYC not verified")

    plan = plans_col.find_one({"_id": ObjectId(payload.plan_id)})
    if not plan:
        raise HTTPException(404, "Plan not found")

    sim_doc = {
        "customer_id": payload.customer_id,
        "plan_id": payload.plan_id,
        "sim_number": payload.sim_number,
        "iccid": f"89{ObjectId()}"[:20],
        "status": "active",
        "activation_date": datetime.utcnow(),
        "validity_end": datetime.utcnow() + timedelta(days=plan["validity_days"]),
        "data_limit": plan["data_limit_gb"],
        "voice_limit": plan["voice_limit_mins"],
        "sms_limit": plan["sms_limit"],
    }
    sim_result = sim_cards_col.update_one(
        {"sim_number": payload.sim_number},
        {"$set": sim_doc},
        upsert=True,
    )
    customers_col.update_one(
        {"_id": ObjectId(payload.customer_id)},
        {"$set": {"plan_id": payload.plan_id, "status": "active"}},
    )
    return {"message": "Plan activated", "sim_number": payload.sim_number, "plan": plan["plan_name"]}
