from fastapi import APIRouter, HTTPException
from datetime import datetime, timedelta
from bson import ObjectId

from ..database import usage_records_col, invoices_col, customers_col, plans_col

router = APIRouter(prefix="/billing", tags=["5. Billing"])

# simple per-unit rating rules (Rate Card) used when usage exceeds plan limits
RATE_CARD = {"voice": 0.5, "sms": 0.2, "data": 8.0}  # INR per min / sms / GB


def serialize(doc):
    doc["id"] = str(doc.pop("_id"))
    return doc


@router.post("/generate")
def generate_invoice(customer_id: str):
    """Step 5 of Business Flow: apply rating, calculate charges, generate invoice."""
    customer = customers_col.find_one({"_id": ObjectId(customer_id)})
    if not customer:
        raise HTTPException(404, "Customer not found")

    plan = plans_col.find_one({"_id": ObjectId(customer["plan_id"])}) if customer.get("plan_id") else None
    base_price = plan["price"] if plan else 0

    pipeline = [
        {"$match": {"customer_id": customer_id}},
        {"$group": {"_id": "$usage_type", "total": {"$sum": "$quantity"}}},
    ]
    usage = {r["_id"]: r["total"] for r in usage_records_col.aggregate(pipeline)}

    overage = 0.0
    breakdown = {}
    if plan:
        for u_type, limit_key in [("voice", "voice_limit_mins"), ("sms", "sms_limit"), ("data", "data_limit_gb")]:
            used = usage.get(u_type, 0)
            limit = plan.get(limit_key, 0)
            extra = max(0, used - limit)
            charge = extra * RATE_CARD[u_type]
            overage += charge
            breakdown[u_type] = {"used": used, "limit": limit, "extra": extra, "charge": round(charge, 2)}

    total = round(base_price + overage, 2)
    invoice = {
        "customer_id": customer_id,
        "plan_amount": base_price,
        "overage_amount": round(overage, 2),
        "amount": total,
        "breakdown": breakdown,
        "status": "unpaid",
        "due_date": datetime.utcnow() + timedelta(days=15),
        "created_at": datetime.utcnow(),
    }
    result = invoices_col.insert_one(invoice)
    invoice["_id"] = result.inserted_id
    return serialize(invoice)


@router.get("/{customer_id}")
def list_invoices(customer_id: str):
    return [serialize(i) for i in invoices_col.find({"customer_id": customer_id}).sort("created_at", -1)]
