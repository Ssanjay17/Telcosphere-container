from fastapi import APIRouter

from ..ml.fraud_detection import check_fraud
from ..ml.churn_prediction import predict_churn
from ..ml.recommendation import recommend_plan
from ..ml.forecasting import forecast_usage

router = APIRouter(prefix="/ml", tags=["AI / ML - Fraud Detection & Monitoring"])


@router.get("/fraud/{customer_id}")
def fraud_check(customer_id: str):
    return check_fraud(customer_id)


@router.get("/churn/{customer_id}")
def churn_check(customer_id: str):
    return predict_churn(customer_id)


@router.get("/recommend/{customer_id}")
def plan_recommendation(customer_id: str, top_n: int = 3):
    return recommend_plan(customer_id, top_n)


@router.get("/forecast/{customer_id}")
def usage_forecast(customer_id: str, usage_type: str = "data"):
    return forecast_usage(customer_id, usage_type)
