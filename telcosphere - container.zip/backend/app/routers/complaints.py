from fastapi import APIRouter, HTTPException
from datetime import datetime
from bson import ObjectId

from ..database import complaints_col
from ..models import ComplaintCreate, ComplaintUpdate

router = APIRouter(prefix="/complaints", tags=["8. Complaint Handling"])


def serialize(doc):
    doc["id"] = str(doc.pop("_id"))
    return doc


@router.post("")
def raise_complaint(payload: ComplaintCreate):
    """Step 6 of Business Flow: Service Support - raise ticket."""
    doc = payload.model_dump()
    doc.update({
        "status": "open",
        "assigned_to": None,
        "created_at": datetime.utcnow(),
    })
    result = complaints_col.insert_one(doc)
    doc["_id"] = result.inserted_id
    return serialize(doc)


@router.get("")
def list_complaints(status: str | None = None):
    query = {"status": status} if status else {}
    return [serialize(c) for c in complaints_col.find(query).sort("created_at", -1)]


@router.patch("/{complaint_id}")
def update_complaint(complaint_id: str, payload: ComplaintUpdate):
    """Assign & resolve - Business Process 8: 'raise ticket, assign and resolve'."""
    update = payload.model_dump(exclude_none=True)
    result = complaints_col.update_one({"_id": ObjectId(complaint_id)}, {"$set": update})
    if result.matched_count == 0:
        raise HTTPException(404, "Complaint not found")
    return {"complaint_id": complaint_id, **update}
