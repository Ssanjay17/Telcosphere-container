"""
TelcoSphere - Next Gen Telecommunication Platform (non-containerized build)
FastAPI acts as the API Gateway (Section 2: High Level System Architecture)
routing to the "microservice-style" routers below, backed by MongoDB.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse, Response
from pathlib import Path

from .database import init_indexes
from .routers import customers, plans, usage, billing, payments, complaints, ml, dashboard, auth


class NoCacheStaticFiles(StaticFiles):
    """
    Root-cause fix for "I edited app.js/index.html but the browser still runs
    the old version": FastAPI's StaticFiles doesn't send any Cache-Control
    header by default, so browsers are free to (and do) keep serving a
    previously-cached copy of app.js / index.html forever. That's why UI
    changes (like the Open Tickets section, or the active/suspend button
    logic) can look like they "didn't apply" even though the files on disk
    are correct - the browser never re-requested them.

    This forces every file served from /app/ to be revalidated on every
    request, so a hard refresh (or even a normal refresh) always picks up
    the latest frontend code.
    """

    async def get_response(self, path: str, scope):
        response: Response = await super().get_response(path, scope)
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response

app = FastAPI(
    title="TelcoSphere API",
    description="Next Gen Telecommunication Platform - Customer, Plan, Usage, Billing, "
                 "Payment, Complaint & AI/ML services backed by MongoDB.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    init_indexes()
    auth.ensure_default_admin()


app.include_router(auth.router)
app.include_router(customers.router)
app.include_router(plans.router)
app.include_router(usage.router)
app.include_router(billing.router)
app.include_router(payments.router)
app.include_router(complaints.router)
app.include_router(ml.router)
app.include_router(dashboard.router)


@app.get("/")
def root():
    return RedirectResponse(url="/app/")


@app.get("/app")
def app_no_slash():
    """Handles /app (no trailing slash) by sending the browser to /app/."""
    return RedirectResponse(url="/app/")


@app.get("/health")
def health():
    return {"status": "ok"}


# Serve the simple frontend directly from FastAPI (no separate container/server needed)
frontend_dir = Path(__file__).resolve().parent.parent.parent / "frontend"
if frontend_dir.exists():
    app.mount("/app/", NoCacheStaticFiles(directory=str(frontend_dir), html=True), name="frontend")
else:
    print(f"WARNING: frontend directory not found at {frontend_dir} - /app will 404")
