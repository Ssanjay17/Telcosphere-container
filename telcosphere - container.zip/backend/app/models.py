from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime


# ---------- 1. Customer Onboarding & KYC ----------
class CustomerCreate(BaseModel):
    name: str
    mobile: str
    email: EmailStr
    dob: Optional[str] = None
    address: Optional[str] = None
    kyc_document_id: Optional[str] = Field(None, description="e.g. Aadhaar/Passport number")


class KYCVerify(BaseModel):
    kyc_status: str = Field(..., pattern="^(pending|verified|rejected)$")


class StatusUpdate(BaseModel):
    status: str = Field(..., pattern="^(active|suspended)$")


# ---------- 2. Plan / SIM Activation ----------
class PlanCreate(BaseModel):
    plan_name: str
    type: str = Field(..., pattern="^(prepaid|postpaid)$")
    price: float
    data_limit_gb: float
    voice_limit_mins: int
    sms_limit: int
    validity_days: int


class PlanActivate(BaseModel):
    customer_id: str
    plan_id: str
    sim_number: str


# ---------- 3 & 4. Usage Generation / Processing ----------
class UsageEvent(BaseModel):
    customer_id: str
    usage_type: str = Field(..., pattern="^(voice|sms|data)$")
    quantity: float  # minutes / count / MB
    source: Optional[str] = "network"


# ---------- 5. Billing ----------
class BillingRequest(BaseModel):
    customer_id: str
    period_start: Optional[str] = None
    period_end: Optional[str] = None


# ---------- 6. Payment ----------
class PaymentRequest(BaseModel):
    invoice_id: str
    amount: float
    method: str = Field(..., pattern="^(card|upi|netbanking|wallet|razorpay)$")


# ---------- Admin Auth (demo-grade: hashed passwords, in-memory tokens) ----------
class AdminLogin(BaseModel):
    username: str
    password: str


class AdminCreate(BaseModel):
    username: str
    password: str


# ---------- 8. Complaint Handling ----------
class ComplaintCreate(BaseModel):
    customer_id: str
    category: str
    description: str


class ComplaintUpdate(BaseModel):
    status: str = Field(..., pattern="^(open|in_progress|resolved|closed)$")
    assigned_to: Optional[str] = None
