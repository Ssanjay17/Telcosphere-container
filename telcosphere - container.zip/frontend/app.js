// The frontend is always served by the same FastAPI app that exposes the API
// (see main.py: app.mount("/app/", ...)), so API calls should always be
// same-origin/relative - this works no matter which port uvicorn runs on.
const API = "";

let activeCustomerId = localStorage.getItem("activeCustomerId") || "";

async function api(path, method = "GET", body = null) {
  const opts = { method, headers: { "Content-Type": "application/json" } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(API + path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || res.statusText);
  return data;
}

function show(id, data) {
  document.getElementById(id).textContent = JSON.stringify(data, null, 2);
}

// ---------- Visible error banner ----------
// Previously, background loads (loadCustomers/loadComplaints/loadDashboard)
// only did console.error() on failure, so if the API call failed the UI
// just silently stayed empty/stale with no indication anything went wrong -
// this made real backend errors indistinguishable from a caching problem.
// Now any load failure surfaces a dismissible banner at the top of the page.
function showError(context, err) {
  console.error(context, err);
  let banner = document.getElementById("globalErrorBanner");
  if (!banner) {
    banner = document.createElement("div");
    banner.id = "globalErrorBanner";
    banner.style.cssText =
      "background:#ef4444;color:#fff;padding:10px 16px;font:13px sans-serif;" +
      "display:flex;justify-content:space-between;align-items:center;gap:12px;";
    document.body.prepend(banner);
  }
  const msg = document.createElement("span");
  msg.textContent = `${context}: ${err.message || err}`;
  const closeBtn = document.createElement("button");
  closeBtn.textContent = "\u2715";
  closeBtn.style.cssText = "background:none;border:none;color:#fff;cursor:pointer;font-size:14px;";
  closeBtn.onclick = () => banner.remove();
  banner.innerHTML = "";
  banner.appendChild(msg);
  banner.appendChild(closeBtn);
}

// ---------- Active customer helper: keeps every "Customer ID" field in sync ----------
function setActiveCustomer(id) {
  activeCustomerId = id || "";
  localStorage.setItem("activeCustomerId", activeCustomerId);
  document.querySelectorAll('input[name="customer_id"]').forEach((el) => {
    el.value = activeCustomerId;
  });
  const badge = document.getElementById("activeCustomerBadge");
  if (activeCustomerId) {
    badge.textContent = "Active customer: " + activeCustomerId;
    badge.className = "badge-active";
  } else {
    badge.textContent = "No active customer selected";
    badge.className = "badge-inactive";
  }
}

// ---------- Dashboard ----------
async function loadDashboard() {
  try {
    const d = await api("/dashboard");
    const grid = document.getElementById("kpiGrid");
    grid.innerHTML = "";
    const items = [
      ["Total Subscribers", d.total_subscribers],
      ["Active Subscribers", d.active_subscribers],
      ["Data Usage Today (MB)", d.data_usage_today_mb],
      ["Revenue Today", "₹" + d.revenue_today],
      ["Open Complaints", d.open_complaints],
      ["Unpaid Invoices", d.unpaid_invoices],
    ];
    items.forEach(([label, value]) => {
      grid.innerHTML += `<div class="kpi"><div class="label">${label}</div><div class="value">${value}</div></div>`;
    });
  } catch (e) { showError("Failed to load dashboard", e); }
}

// ---------- Plans dropdown ----------
async function loadPlans() {
  try {
    const plans = await api("/plans");
    const select = document.getElementById("planSelect");
    if (plans.length === 0) {
      select.innerHTML = `<option value="">No plans yet - create one via /docs (POST /plans)</option>`;
      return;
    }
    select.innerHTML = plans.map(p => `<option value="${p.id}">${p.plan_name} - ₹${p.price} (${p.type})</option>`).join("");
  } catch (e) { showError("Failed to load plans", e); }
}

// ---------- Customer list (so IDs never have to be typed by hand) ----------
async function loadCustomers() {
  try {
    const customers = await api("/customers?limit=20");
    const wrap = document.getElementById("customerList");
    if (customers.length === 0) {
      wrap.innerHTML = `<p class="hint">No customers yet. Register one below.</p>`;
      return;
    }
    const rows = customers.map((c) => `
      <tr>
        <td>${c.name}</td>
        <td>${c.mobile}</td>
        <td><span class="pill pill-${c.kyc_status}">${c.kyc_status}</span></td>
        <td><span class="pill pill-${c.status === 'active' ? 'verified' : 'rejected'}">${c.status}</span></td>
        <td><code>${c.id}</code></td>
        <td class="actions">
          <button type="button" class="secondary use-customer" data-id="${c.id}">Use</button>
          <button type="button" class="toggle-status ${c.status === 'active' ? 'danger' : 'success'}" data-id="${c.id}" data-status="${c.status}">
            ${c.status === "active" ? "Suspend" : "Activate"}
          </button>
        </td>
      </tr>`).join("");
    wrap.innerHTML = `
      <table>
        <thead><tr><th>Name</th><th>Mobile</th><th>KYC</th><th>Status</th><th>ID</th><th></th></tr></thead>
        <tbody>${rows}</tbody>
      </table>`;
    wrap.querySelectorAll(".use-customer").forEach((btn) => {
      btn.addEventListener("click", () => setActiveCustomer(btn.dataset.id));
    });
    wrap.querySelectorAll(".toggle-status").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const next = btn.dataset.status === "active" ? "suspended" : "active";
        try {
          await api(`/customers/${btn.dataset.id}/status`, "POST", { status: next });
          await loadCustomers();
          await loadDashboard();
        } catch (err) { alert("Failed to update status: " + err.message); }
      });
    });
  } catch (e) { showError("Failed to load customers", e); }
}

async function refreshAll() {
  await Promise.all([loadDashboard(), loadPlans(), loadCustomers(), loadComplaints()]);
}

// ---------- 8. Complaints list (open/in_progress -> resolved) ----------
async function loadComplaints() {
  try {
    const complaints = await api("/complaints");
    const wrap = document.getElementById("complaintList");
    if (!wrap) return;
    if (complaints.length === 0) {
      wrap.innerHTML = `<p class="hint">No complaints raised yet.</p>`;
      return;
    }
    const rows = complaints.map((c) => `
      <tr>
        <td><code>${c.customer_id}</code></td>
        <td>${c.category}</td>
        <td>${c.description || ""}</td>
        <td><span class="pill pill-${c.status}">${c.status.replace("_", " ")}</span></td>
        <td class="actions">
          ${c.status !== "resolved" && c.status !== "closed"
            ? `<button type="button" class="success resolve-complaint" data-id="${c.id}">Resolve</button>`
            : ""}
          ${c.status === "open"
            ? `<button type="button" class="secondary progress-complaint" data-id="${c.id}">In Progress</button>`
            : ""}
        </td>
      </tr>`).join("");
    wrap.innerHTML = `
      <table>
        <thead><tr><th>Customer ID</th><th>Category</th><th>Description</th><th>Status</th><th></th></tr></thead>
        <tbody>${rows}</tbody>
      </table>`;
    wrap.querySelectorAll(".resolve-complaint").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await api(`/complaints/${btn.dataset.id}`, "PATCH", { status: "resolved" });
          await loadComplaints();
          await loadDashboard();
        } catch (err) { alert("Failed to resolve complaint: " + err.message); }
      });
    });
    wrap.querySelectorAll(".progress-complaint").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await api(`/complaints/${btn.dataset.id}`, "PATCH", { status: "in_progress" });
          await loadComplaints();
        } catch (err) { alert("Failed to update complaint: " + err.message); }
      });
    });
  } catch (e) { showError("Failed to load Open Tickets", e); }
}

// ---------- 1. Register customer ----------
document.getElementById("customerForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(e.target));
  try {
    const result = await api("/customers", "POST", fd);
    show("customerResult", result);
    setActiveCustomer(result.id); // auto-fill every other form
    e.target.reset();
    await refreshAll();
  } catch (err) { show("customerResult", { error: err.message }); }
});

// ---------- 1b. KYC verification (previously missing - activation was silently unreachable) ----------
document.getElementById("kycForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(e.target));
  try {
    const result = await api(`/customers/${fd.customer_id}/kyc`, "POST", { kyc_status: fd.kyc_status });
    show("kycResult", result);
    await loadCustomers();
  } catch (err) { show("kycResult", { error: err.message }); }
});

// ---------- 2. Activate plan ----------
document.getElementById("activateForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(e.target));
  try {
    const result = await api("/plans/activate", "POST", fd);
    show("activateResult", result);
    await refreshAll();
  } catch (err) { show("activateResult", { error: err.message }); }
});

// ---------- 3-4. Record usage ----------
document.getElementById("usageForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(e.target));
  fd.quantity = parseFloat(fd.quantity);
  try {
    const result = await api("/usage", "POST", fd);
    show("usageResult", result);
    await loadDashboard();
  } catch (err) { show("usageResult", { error: err.message }); }
});

// ---------- 5. Generate invoice -> auto-fill payment form ----------
document.getElementById("billingForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(e.target));
  try {
    const invoice = await api(`/billing/generate?customer_id=${fd.customer_id}`, "POST");
    show("billingResult", invoice);
    const paymentForm = document.getElementById("paymentForm");
    paymentForm.elements["invoice_id"].value = invoice.id;
    paymentForm.elements["amount"].value = invoice.amount;
  } catch (err) { show("billingResult", { error: err.message }); }
});

// ---------- 6. Pay invoice ----------
document.getElementById("paymentForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(e.target));
  fd.amount = parseFloat(fd.amount);
  try {
    const result = await api("/payments", "POST", fd);
    show("paymentResult", result);
    await loadDashboard();
  } catch (err) { show("paymentResult", { error: err.message }); }
});

// ---------- 8. Complaints ----------
document.getElementById("complaintForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(e.target));
  try {
    const result = await api("/complaints", "POST", fd);
    show("complaintResult", result);
    await loadDashboard();
    await loadComplaints();
  } catch (err) { show("complaintResult", { error: err.message }); }
});

// ---------- AI / ML ----------
let mlChartInstance = null;

function destroyChart() {
  if (mlChartInstance) { mlChartInstance.destroy(); mlChartInstance = null; }
}

// Guard: if vendor/chart.umd.min.js failed to load (e.g. the file is missing,
// or someone reverts to a CDN <script> tag that gets blocked), `Chart` won't
// exist on window. Fail with a clear, actionable message in the ML panel
// instead of throwing "Chart is not defined" from deep inside a render*Chart call.
function chartLibraryReady() {
  if (typeof Chart === "undefined") {
    show("mlResult", {
      error: "Chart.js failed to load. Check that frontend/vendor/chart.umd.min.js " +
             "exists and that index.html points to it (<script src=\"vendor/chart.umd.min.js\">).",
    });
    return false;
  }
  return true;
}

// Fraud: bar chart of the customer's raw usage feature vector.
// Bar color communicates the model's verdict (red = anomalous, teal = normal),
// since Isolation Forest's output is a binary flag + a continuous score, not
// something naturally pie-shaped.
function renderFraudChart(result) {
  const ctx = document.getElementById("mlChart").getContext("2d");
  if (!result.feature_vector) return;
  const fv = result.feature_vector;
  const color = result.is_anomalous ? "#D85A30" : "#1D9E75";
  mlChartInstance = new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Voice (mins)", "SMS (count)", "Data (MB)", "Total events"],
      datasets: [{
        label: result.is_anomalous ? "Anomalous usage pattern" : "Normal usage pattern",
        data: [fv.voice_mins, fv.sms_count, fv.data_mb, fv.total_events],
        backgroundColor: color,
      }],
    },
    options: {
      plugins: { title: { display: true, text: `Anomaly score: ${result.anomaly_score ?? "N/A"}` } },
      scales: { y: { beginAtZero: true } },
    },
  });
}

// Churn: doughnut of churn vs. retention probability. This IS naturally a
// pie/donut - it's a single probability that sums to 1 with its complement.
function renderChurnChart(result) {
  const ctx = document.getElementById("mlChart").getContext("2d");
  if (result.churn_probability === undefined) return;
  const churn = result.churn_probability;
  const retain = 1 - churn;
  const riskColor = { high: "#D85A30", medium: "#EF9F27", low: "#1D9E75" }[result.risk_level] || "#7F77DD";
  mlChartInstance = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Churn probability", "Retention probability"],
      datasets: [{ data: [churn, retain], backgroundColor: [riskColor, "#D3D1C7"] }],
    },
    options: {
      plugins: { title: { display: true, text: `Risk level: ${result.risk_level} (${(churn * 100).toFixed(1)}%)` } },
    },
  });
}

// Recommend: bar chart comparing match_score across the top-N recommended
// plans - naturally a ranked comparison, not a part-of-whole pie.
function renderRecommendChart(result) {
  const ctx = document.getElementById("mlChart").getContext("2d");
  const recs = result.recommendations || [];
  if (recs.length === 0) return;
  mlChartInstance = new Chart(ctx, {
    type: "bar",
    data: {
      labels: recs.map(r => r.plan_name),
      datasets: [{
        label: "Match score (cosine similarity)",
        data: recs.map(r => r.match_score),
        backgroundColor: "#4130c9",
      }],
    },
    options: { indexAxis: "y", plugins: { legend: { display: false } } },
  });
}

// Forecast: bar comparing current cumulative usage vs. the projected next
// period - two absolute quantities being compared, so a bar (not a pie).
function renderForecastChart(result) {
  const ctx = document.getElementById("mlChart").getContext("2d");
  if (result.current_total === undefined) return;
  mlChartInstance = new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Current total", "Projected next period"],
      datasets: [{
        data: [result.current_total, result.projected_next_period_usage],
        backgroundColor: [ "#7F77DD", result.trend === "increasing" ? "#D85A30" : "#1D9E75"],
      }],
    },
    options: {
      plugins: {
        legend: { display: false },
        title: { display: true, text: `${result.usage_type} usage - trend: ${result.trend}` },
      },
    },
  });
}

document.getElementById("mlForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const action = e.submitter.dataset.action;
  const fd = Object.fromEntries(new FormData(e.target));
  const routes = {
    fraud: `/ml/fraud/${fd.customer_id}`,
    churn: `/ml/churn/${fd.customer_id}`,
    recommend: `/ml/recommend/${fd.customer_id}`,
    forecast: `/ml/forecast/${fd.customer_id}`,
  };
  destroyChart();
  if (!chartLibraryReady()) return;
  try {
    const result = await api(routes[action]);
    show("mlResult", result);
    const renderers = { fraud: renderFraudChart, churn: renderChurnChart, recommend: renderRecommendChart, forecast: renderForecastChart };
    renderers[action](result);
  } catch (err) { show("mlResult", { error: err.message }); }
});

// ---------- Manual refresh button ----------
document.getElementById("refreshCustomers").addEventListener("click", loadCustomers);
document.getElementById("refreshComplaints").addEventListener("click", loadComplaints);

// ---------- Init ----------
setActiveCustomer(activeCustomerId);
refreshAll();
setInterval(loadDashboard, 15000);
