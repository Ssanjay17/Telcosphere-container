# TelcoSphere — Python + AI/ML + MongoDB (No Containers)

A working implementation of the TelcoSphere platform diagram: FastAPI backend,
MongoDB database, AI/ML services, and a lightweight HTML/JS frontend — run
directly on your machine, no Docker/Podman required.

## What maps to what in the diagram

| Diagram Section | Implementation |
|---|---|
| 1. Business Flow (Customer Journey) | `routers/customers.py`, `plans.py`, `usage.py`, `billing.py`, `payments.py`, `complaints.py` |
| 2. High Level System Architecture (API Gateway + Microservices) | `app/main.py` (FastAPI as gateway) + per-domain routers |
| 4. Core Business Processes (9 steps) | Endpoints in each router, documented in docstrings |
| 5. Key Features (Fraud Detection AI/ML, Offers/Loyalty, etc.) | `app/ml/` (fraud_detection, churn_prediction, recommendation, forecasting) |
| 6. Database Design (core tables) | MongoDB collections in `app/database.py`: customers, sim_cards, plans, usage_records, invoices, payments, complaints |
| 8. Operator Dashboard | `routers/dashboard.py` + `frontend/index.html` KPI grid |

## 1. Prerequisites

- Python 3.10+
- MongoDB running locally (`mongodb://localhost:27017`) — install via your OS package
  manager, or use a free MongoDB Atlas cluster and set `MONGO_URI` env var.

## 2. Setup

```bash
cd telcosphere/backend
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 3. (Optional) Seed sample data

Populates sample plans, customers, and simulated usage so dashboard/ML endpoints
have data immediately:

```bash
python -m app.seed_data
```

## 4. Run the backend

```bash
uvicorn app.main:app --reload --port 8000
```

- API docs (Swagger): http://localhost:8000/docs
- Frontend dashboard: http://localhost:8000/app  (FastAPI serves the frontend directly)

## 5. Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `MONGO_URI` | `mongodb://localhost:27017` | MongoDB connection string |
| `DB_NAME` | `telcosphere` | Database name |

## 6. API overview

- `POST /customers` — Register + KYC capture
- `POST /customers/{id}/kyc` — Verify KYC
- `POST /plans` / `GET /plans` — Manage plan catalog
- `POST /plans/activate` — Activate SIM + plan for a customer
- `POST /usage` — Record a usage event (voice/sms/data)
- `GET /usage/{customer_id}/summary` — Aggregated usage
- `POST /billing/generate?customer_id=...` — Generate invoice with overage rating
- `POST /payments` — Pay an invoice (UPI/card/netbanking/wallet/razorpay)
- `POST /complaints` / `PATCH /complaints/{id}` — Raise & resolve complaints
- `GET /ml/fraud/{customer_id}` — Isolation Forest anomaly detection
- `GET /ml/churn/{customer_id}` — Churn risk scoring
- `GET /ml/recommend/{customer_id}` — Plan recommendation
- `GET /ml/forecast/{customer_id}` — Usage forecasting
- `GET /dashboard` — Operator dashboard KPIs

## 7. Typical demo flow

1. `POST /customers` → get `id`
2. `POST /customers/{id}/kyc` with `{"kyc_status": "verified"}`
3. `POST /plans/activate` with the customer_id, a plan_id (from `GET /plans`), and a sim_number
4. `POST /usage` a few times (voice/sms/data)
5. `POST /billing/generate?customer_id=...` → get invoice
6. `POST /payments` to pay it
7. Hit the `/ml/*` endpoints to see AI/ML output
8. Open `http://localhost:8000/app` to do all of this from the browser

---
**Note:** This is the non-containerized build. When you're ready for the
containerized version (Section 3 & 9 of the diagram: Podman network with
separate Frontend/API Gateway/Microservices/DB containers, or OpenShift
deployment), just say **"create as container project"** and I'll containerize
this same codebase accordingly.
