"""
telcosphere-aiml - Container 6/6

Owns: GET /ml/fraud/{id}, /ml/churn/{id}, /ml/recommend/{id}, /ml/forecast/{id}.
This is the heaviest image (scikit-learn/numpy/pandas) - kept split from the
lightweight CRUD services on purpose, since it's the container most likely to
need its own scaling/resource limits in a real deployment.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from common.database import init_indexes
from common.ml.fraud_detection import check_fraud
from common.ml.churn_prediction import predict_churn
from common.ml.recommendation import recommend_plan
from common.ml.forecasting import forecast_usage

app = FastAPI(title="telcosphere-aiml", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
def startup():
    init_indexes()


@app.get("/health")
def health():
    return {"status": "ok", "container": "telcosphere-aiml"}


@app.get("/ml/fraud/{customer_id}")
def fraud_check(customer_id: str):
    return check_fraud(customer_id)


@app.get("/ml/churn/{customer_id}")
def churn_check(customer_id: str):
    return predict_churn(customer_id)


@app.get("/ml/recommend/{customer_id}")
def plan_recommendation(customer_id: str, top_n: int = 3):
    return recommend_plan(customer_id, top_n)


@app.get("/ml/forecast/{customer_id}")
def usage_forecast(customer_id: str, usage_type: str = "data"):
    return forecast_usage(customer_id, usage_type)
