"""
telcosphere-subscribers - Container 2/6

Owns: GET /customers (list), GET /customers/{id}, POST /customers/{id}/status
      (the active/suspend toggle). Registration and KYC live in
      telcosphere-onboarding instead - this container is read/manage-existing,
      not create-new.
"""
from bson import ObjectId
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from common.database import init_indexes, customers_col
from common.models import StatusUpdate

app = FastAPI(title="telcosphere-subscribers", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
def startup():
    init_indexes()


def serialize(doc):
    doc["id"] = str(doc.pop("_id"))
    return doc


@app.get("/health")
def health():
    return {"status": "ok", "container": "telcosphere-subscribers"}


@app.get("/customers")
def list_customers(limit: int = 50):
    return [serialize(c) for c in customers_col.find().sort("created_at", -1).limit(limit)]


@app.get("/customers/{customer_id}")
def get_customer(customer_id: str):
    doc = customers_col.find_one({"_id": ObjectId(customer_id)})
    if not doc:
        raise HTTPException(404, "Customer not found")
    return serialize(doc)


@app.post("/customers/{customer_id}/status")
def update_status(customer_id: str, payload: StatusUpdate):
    """Activate or suspend a customer's SIM/account - the add/deactivate button."""
    result = customers_col.update_one(
        {"_id": ObjectId(customer_id)},
        {"$set": {"status": payload.status}},
    )
    if result.matched_count == 0:
        raise HTTPException(404, "Customer not found")
    return {"customer_id": customer_id, "status": payload.status}
