"""
telcosphere-billing - Container 4/6

Owns: POST /billing/generate, GET /billing/{customer_id}, POST /payments,
      GET /payments/{customer_id}.
"""
from datetime import datetime, timedelta

from bson import ObjectId
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from common.database import init_indexes, usage_records_col, invoices_col, customers_col, plans_col, payments_col
from common.models import PaymentRequest

app = FastAPI(title="telcosphere-billing", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# simple per-unit rating rules (Rate Card) used when usage exceeds plan limits
RATE_CARD = {"voice": 0.5, "sms": 0.2, "data": 8.0}  # INR per min / sms / GB


@app.on_event("startup")
def startup():
    init_indexes()


def serialize(doc):
    doc["id"] = str(doc.pop("_id"))
    return doc


@app.get("/health")
def health():
    return {"status": "ok", "container": "telcosphere-billing"}


@app.post("/billing/generate")
def generate_invoice(customer_id: str):
    """Step 5 of Business Flow: apply rating, calculate charges, generate invoice."""
    customer = customers_col.find_one({"_id": ObjectId(customer_id)})
    if not customer:
        raise HTTPException(404, "Customer not found")

    plan = plans_col.find_one({"_id": ObjectId(customer["plan_id"])}) if customer.get("plan_id") else None
    base_price = plan["price"] if plan else 0

    pipeline = [
        {"$match": {"customer_id": customer_id}},
        {"$group": {"_id": "$usage_type", "total": {"$sum": "$quantity"}}},
    ]
    usage = {r["_id"]: r["total"] for r in usage_records_col.aggregate(pipeline)}

    overage = 0.0
    breakdown = {}
    if plan:
        for u_type, limit_key in [("voice", "voice_limit_mins"), ("sms", "sms_limit"), ("data", "data_limit_gb")]:
            used = usage.get(u_type, 0)
            limit = plan.get(limit_key, 0)
            extra = max(0, used - limit)
            charge = extra * RATE_CARD[u_type]
            overage += charge
            breakdown[u_type] = {"used": used, "limit": limit, "extra": extra, "charge": round(charge, 2)}

    total = round(base_price + overage, 2)
    invoice = {
        "customer_id": customer_id,
        "plan_amount": base_price,
        "overage_amount": round(overage, 2),
        "amount": total,
        "breakdown": breakdown,
        "status": "unpaid",
        "due_date": datetime.utcnow() + timedelta(days=15),
        "created_at": datetime.utcnow(),
    }
    result = invoices_col.insert_one(invoice)
    invoice["_id"] = result.inserted_id
    return serialize(invoice)


@app.get("/billing/{customer_id}")
def list_invoices(customer_id: str):
    return [serialize(i) for i in invoices_col.find({"customer_id": customer_id}).sort("created_at", -1)]


@app.post("/payments")
def make_payment(payload: PaymentRequest):
    """Step 6 of Business Flow: customer pays bill through multiple channels."""
    invoice = invoices_col.find_one({"_id": ObjectId(payload.invoice_id)})
    if not invoice:
        raise HTTPException(404, "Invoice not found")
    if invoice["status"] == "paid":
        raise HTTPException(400, "Invoice already paid")

    doc = {
        "invoice_id": payload.invoice_id,
        "customer_id": invoice["customer_id"],
        "amount": payload.amount,
        "method": payload.method,
        "status": "success" if abs(payload.amount - invoice["amount"]) < 0.01 else "partial",
        "transaction_id": f"TXN{ObjectId()}"[:18].upper(),
        "paid_at": datetime.utcnow(),
    }
    result = payments_col.insert_one(doc)
    doc["_id"] = result.inserted_id

    if doc["status"] == "success":
        invoices_col.update_one({"_id": ObjectId(payload.invoice_id)}, {"$set": {"status": "paid"}})

    return serialize(doc)


@app.get("/payments/{customer_id}")
def list_payments(customer_id: str):
    return [serialize(p) for p in payments_col.find({"customer_id": customer_id}).sort("paid_at", -1)]
