"""
telcosphere-onboarding - Container 3/6

Owns every "form filling" step of bringing a subscriber onto the network:
  POST /customers            - registration
  POST /customers/{id}/kyc   - KYC verification
  GET  /plans                - plan catalog (for the plan-select dropdown)
  POST /plans/activate       - plan selection + SIM activation
  POST /usage                - usage/CDR entry
  GET  /usage/{id}           - usage history
  GET  /usage/{id}/summary   - usage summary
"""
from datetime import datetime, timedelta

from bson import ObjectId
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from common.database import init_indexes, customers_col, plans_col, sim_cards_col, usage_records_col
from common.models import CustomerCreate, KYCVerify, PlanActivate

app = FastAPI(title="telcosphere-onboarding", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
def startup():
    init_indexes()


def serialize(doc):
    doc["id"] = str(doc.pop("_id"))
    return doc


@app.get("/health")
def health():
    return {"status": "ok", "container": "telcosphere-onboarding"}


# ---------- Registration & KYC ----------

@app.post("/customers")
def register_customer(payload: CustomerCreate):
    """Step 1 of Business Flow: Customer Registration & KYC capture."""
    if customers_col.find_one({"mobile": payload.mobile}):
        raise HTTPException(400, "Customer with this mobile already exists")

    doc = payload.model_dump()
    doc.update({
        "kyc_status": "pending",
        "created_at": datetime.utcnow(),
        "plan_id": None,
        "status": "active",
    })
    result = customers_col.insert_one(doc)
    doc["_id"] = result.inserted_id
    return serialize(doc)


@app.post("/customers/{customer_id}/kyc")
def verify_kyc(customer_id: str, payload: KYCVerify):
    """KYC verification step - unlocks plan activation."""
    result = customers_col.update_one(
        {"_id": ObjectId(customer_id)},
        {"$set": {"kyc_status": payload.kyc_status}},
    )
    if result.matched_count == 0:
        raise HTTPException(404, "Customer not found")
    return {"customer_id": customer_id, "kyc_status": payload.kyc_status}


# ---------- Plan selection & SIM activation ----------

@app.get("/plans")
def list_plans():
    return [serialize(p) for p in plans_col.find()]


@app.post("/plans/activate")
def activate_plan(payload: PlanActivate):
    """Step 2 of Business Flow: Plan Selection & SIM Activation."""
    customer = customers_col.find_one({"_id": ObjectId(payload.customer_id)})
    if not customer:
        raise HTTPException(404, "Customer not found")
    if customer.get("kyc_status") != "verified":
        raise HTTPException(400, "Cannot activate plan: KYC not verified")

    plan = plans_col.find_one({"_id": ObjectId(payload.plan_id)})
    if not plan:
        raise HTTPException(404, "Plan not found")

    sim_doc = {
        "customer_id": payload.customer_id,
        "plan_id": payload.plan_id,
        "sim_number": payload.sim_number,
        "iccid": f"89{ObjectId()}"[:20],
        "status": "active",
        "activation_date": datetime.utcnow(),
        "validity_end": datetime.utcnow() + timedelta(days=plan["validity_days"]),
        "data_limit": plan["data_limit_gb"],
        "voice_limit": plan["voice_limit_mins"],
        "sms_limit": plan["sms_limit"],
    }
    sim_cards_col.update_one(
        {"sim_number": payload.sim_number},
        {"$set": sim_doc},
        upsert=True,
    )
    customers_col.update_one(
        {"_id": ObjectId(payload.customer_id)},
        {"$set": {"plan_id": payload.plan_id, "status": "active"}},
    )
    return {"message": "Plan activated", "sim_number": payload.sim_number, "plan": plan["plan_name"]}


# ---------- Usage generation ----------

@app.post("/usage")
def record_usage(payload: dict):
    """Step 3-4 of Business Flow: Usage Generation & Processing."""
    customer_id = payload.get("customer_id")
    if not customers_col.find_one({"_id": ObjectId(customer_id)}):
        raise HTTPException(404, "Customer not found")

    doc = {
        "customer_id": customer_id,
        "usage_type": payload["usage_type"],
        "quantity": payload["quantity"],
        "event_time": datetime.utcnow(),
        "source": payload.get("source", "network"),
        "chargeable": True,
    }
    result = usage_records_col.insert_one(doc)
    doc["_id"] = result.inserted_id
    return serialize(doc)


@app.get("/usage/{customer_id}")
def get_usage(customer_id: str, limit: int = 100):
    records = list(
        usage_records_col.find({"customer_id": customer_id}).sort("event_time", -1).limit(limit)
    )
    return [serialize(r) for r in records]


@app.get("/usage/{customer_id}/summary")
def usage_summary(customer_id: str):
    pipeline = [
        {"$match": {"customer_id": customer_id}},
        {"$group": {"_id": "$usage_type", "total": {"$sum": "$quantity"}, "events": {"$sum": 1}}},
    ]
    agg = {r["_id"]: {"total": r["total"], "events": r["events"]} for r in usage_records_col.aggregate(pipeline)}
    return agg
