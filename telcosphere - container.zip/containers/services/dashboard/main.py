"""
telcosphere-dashboard - Container 1/6

Owns: GET /dashboard (KPI aggregation across subscribers/usage/revenue/complaints)
      /auth/* (admin login - operator-facing, so it lives with the dashboard)

Reads several collections (customers, usage_records, invoices, payments,
complaints) directly from Mongo - dashboards are a classic case where a
microservice is allowed read-only cross-collection access instead of
calling five other services over HTTP just to draw one KPI grid.
"""
from datetime import datetime, timedelta

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from common.database import (
    init_indexes,
    customers_col,
    usage_records_col,
    invoices_col,
    payments_col,
    complaints_col,
)
from common import auth as auth_module

app = FastAPI(title="telcosphere-dashboard", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
def startup():
    init_indexes()
    auth_module.ensure_default_admin()


app.include_router(auth_module.router)


@app.get("/health")
def health():
    return {"status": "ok", "container": "telcosphere-dashboard"}


@app.get("/dashboard")
def get_dashboard():
    total_subscribers = customers_col.count_documents({})
    active_subscribers = customers_col.count_documents({"status": "active"})

    since = datetime.utcnow() - timedelta(days=1)
    today_data_mb = list(usage_records_col.aggregate([
        {"$match": {"usage_type": "data", "event_time": {"$gte": since}}},
        {"$group": {"_id": None, "total": {"$sum": "$quantity"}}},
    ]))
    data_today = today_data_mb[0]["total"] if today_data_mb else 0

    revenue_today = list(payments_col.aggregate([
        {"$match": {"paid_at": {"$gte": since}, "status": "success"}},
        {"$group": {"_id": None, "total": {"$sum": "$amount"}}},
    ]))
    revenue = revenue_today[0]["total"] if revenue_today else 0

    usage_by_type = {r["_id"]: r["total"] for r in usage_records_col.aggregate([
        {"$group": {"_id": "$usage_type", "total": {"$sum": "$quantity"}}},
    ])}

    open_complaints = complaints_col.count_documents({"status": "open"})
    unpaid_invoices = invoices_col.count_documents({"status": "unpaid"})

    return {
        "total_subscribers": total_subscribers,
        "active_subscribers": active_subscribers,
        "data_usage_today_mb": round(data_today, 2),
        "revenue_today": round(revenue, 2),
        "usage_breakdown": usage_by_type,
        "open_complaints": open_complaints,
        "unpaid_invoices": unpaid_invoices,
    }
