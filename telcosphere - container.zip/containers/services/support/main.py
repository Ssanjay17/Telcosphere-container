"""
telcosphere-support - Container 5/6

Owns: POST /complaints, GET /complaints (Open Tickets), PATCH /complaints/{id}.
"""
from datetime import datetime

from bson import ObjectId
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from common.database import init_indexes, complaints_col
from common.models import ComplaintCreate, ComplaintUpdate

app = FastAPI(title="telcosphere-support", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
def startup():
    init_indexes()


def serialize(doc):
    doc["id"] = str(doc.pop("_id"))
    return doc


@app.get("/health")
def health():
    return {"status": "ok", "container": "telcosphere-support"}


@app.post("/complaints")
def raise_complaint(payload: ComplaintCreate):
    """Step 6 of Business Flow: Service Support - raise ticket."""
    doc = payload.model_dump()
    doc.update({
        "status": "open",
        "assigned_to": None,
        "created_at": datetime.utcnow(),
    })
    result = complaints_col.insert_one(doc)
    doc["_id"] = result.inserted_id
    return serialize(doc)


@app.get("/complaints")
def list_complaints(status: str | None = None):
    query = {"status": status} if status else {}
    return [serialize(c) for c in complaints_col.find(query).sort("created_at", -1)]


@app.patch("/complaints/{complaint_id}")
def update_complaint(complaint_id: str, payload: ComplaintUpdate):
    """Assign & resolve - Business Process 8."""
    update = payload.model_dump(exclude_none=True)
    result = complaints_col.update_one({"_id": ObjectId(complaint_id)}, {"$set": update})
    if result.matched_count == 0:
        raise HTTPException(404, "Complaint not found")
    return {"complaint_id": complaint_id, **update}
