"""
Admin authentication (demo-grade).

Design notes for whoever extends this later:
- Passwords ARE hashed (bcrypt via passlib), so this is not "plaintext demo" -
  but tokens are random strings held in an in-memory dict, not signed JWTs,
  and there's no expiry/refresh flow. That's fine for a local demo; before any
  real deployment, swap _SESSIONS for a signed JWT or a persisted session
  store, and add HTTPS + rate limiting on /auth/login.
- Multiple admins are supported today: each is just a document in the
  `admins` collection. Adding more later is just another insert - no schema
  or endpoint changes needed.
"""
import secrets
from datetime import datetime, timedelta

from fastapi import APIRouter, HTTPException, Header
from passlib.context import CryptContext

from .database import admins_col
from .models import AdminLogin, AdminCreate

router = APIRouter(prefix="/auth", tags=["Admin Auth"])
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# token -> {"username": ..., "expires_at": datetime}
# In-memory by design (demo-grade) - restarting the server logs everyone out.
_SESSIONS: dict[str, dict] = {}
_SESSION_HOURS = 12


def ensure_default_admin():
    """Seed a default admin account on first run so login works out of the box."""
    if admins_col.count_documents({}) == 0:
        admins_col.insert_one({
            "username": "admin",
            "password_hash": pwd_context.hash("admin123"),
            "created_at": datetime.utcnow(),
        })
        print("Seeded default admin -> username: admin / password: admin123 (change this!)")


def _current_admin(authorization: str | None):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing or malformed Authorization header")
    token = authorization.removeprefix("Bearer ").strip()
    session = _SESSIONS.get(token)
    if not session or session["expires_at"] < datetime.utcnow():
        _SESSIONS.pop(token, None)
        raise HTTPException(401, "Session expired or invalid - please log in again")
    return session["username"]


@router.post("/login")
def login(payload: AdminLogin):
    admin = admins_col.find_one({"username": payload.username})
    if not admin or not pwd_context.verify(payload.password, admin["password_hash"]):
        raise HTTPException(401, "Invalid username or password")
    token = secrets.token_hex(24)
    _SESSIONS[token] = {
        "username": admin["username"],
        "expires_at": datetime.utcnow() + timedelta(hours=_SESSION_HOURS),
    }
    return {"token": token, "username": admin["username"], "expires_in_hours": _SESSION_HOURS}


@router.post("/logout")
def logout(authorization: str | None = Header(None)):
    if authorization and authorization.startswith("Bearer "):
        _SESSIONS.pop(authorization.removeprefix("Bearer ").strip(), None)
    return {"message": "Logged out"}


@router.get("/me")
def me(authorization: str | None = Header(None)):
    username = _current_admin(authorization)
    return {"username": username}


@router.post("/admins")
def create_admin(payload: AdminCreate, authorization: str | None = Header(None)):
    """Add another admin account. Requires an existing valid session."""
    _current_admin(authorization)  # any logged-in admin may add another (demo-grade policy)
    if admins_col.find_one({"username": payload.username}):
        raise HTTPException(400, "Username already exists")
    admins_col.insert_one({
        "username": payload.username,
        "password_hash": pwd_context.hash(payload.password),
        "created_at": datetime.utcnow(),
    })
    return {"message": "Admin created", "username": payload.username}
