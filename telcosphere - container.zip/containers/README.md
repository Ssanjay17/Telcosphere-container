# TelcoSphere - Podman Container Split

This is the **real containerized build**, split into 6 independent
microservice containers (matching the container cards in the UI) plus
MongoDB and an nginx frontend container. The original `backend/` +
`frontend/` at the repo root is untouched and still works as a single
monolith - this `containers/` directory is a separate, parallel deployment.

## The 6 containers

| Container                | Port | Owns                                              |
|---------------------------|------|----------------------------------------------------|
| `telcosphere-dashboard`   | 8081 | `GET /dashboard`, `/auth/*` (admin login)          |
| `telcosphere-subscribers` | 8082 | `GET /customers`, active/suspend toggle            |
| `telcosphere-onboarding`  | 8083 | register, KYC, plan activation, usage entry        |
| `telcosphere-billing`     | 8084 | invoice generation, payments                       |
| `telcosphere-support`     | 8085 | complaints / open tickets                          |
| `telcosphere-aiml`        | 8086 | fraud, churn, recommend, forecast                  |

Plus:
- `mongo` (27017) - shared database, one collection set for all services
- `telcosphere-frontend` (8080) - static UI (nginx), calls each service
  directly on its own port (see `SERVICE_PORTS` in `frontend/site/app.js`)

Every service's `main.py` is self-contained and imports only from the shared
`common/` package (`database.py`, `models.py`, `auth.py`, `ml/`) - no
service imports another service's code, so each one can be built, scaled,
and redeployed independently.

## Quick start (compose)

```bash
cd containers
podman compose up --build        # or: podman-compose up --build
```

Then seed sample data once (dashboard/AI-ML panels are empty otherwise):

```bash
podman build -t telcosphere/seed:1.0 -f seed/Containerfile .
podman run --rm --network containers_default \
  -e MONGO_URI=mongodb://mongo:27017 telcosphere/seed:1.0
```

Open the UI: **http://localhost:8080**

## Building/running containers one at a time (no compose)

```bash
cd containers
podman network create telcosphere-net
podman run -d --name mongo --network telcosphere-net -p 27017:27017 docker.io/library/mongo:7

for svc in dashboard subscribers onboarding billing support aiml; do
  podman build -t telcosphere/$svc:1.0 -f services/$svc/Containerfile .
done
podman build -t telcosphere/frontend:1.0 -f frontend/Containerfile .

podman run -d --name telcosphere-dashboard   --network telcosphere-net -p 8081:8000 telcosphere/dashboard:1.0
podman run -d --name telcosphere-subscribers --network telcosphere-net -p 8082:8000 telcosphere/subscribers:1.0
podman run -d --name telcosphere-onboarding  --network telcosphere-net -p 8083:8000 telcosphere/onboarding:1.0
podman run -d --name telcosphere-billing     --network telcosphere-net -p 8084:8000 telcosphere/billing:1.0
podman run -d --name telcosphere-support     --network telcosphere-net -p 8085:8000 telcosphere/support:1.0
podman run -d --name telcosphere-aiml        --network telcosphere-net -p 8086:8000 telcosphere/aiml:1.0
podman run -d --name telcosphere-frontend    --network telcosphere-net -p 8080:8080 telcosphere/frontend:1.0
```

Group them into a real Podman pod (optional, closer to the "pod" concept
shown in the UI's top strip):

```bash
podman pod create --name telcosphere-pod -p 8080:8080 -p 8081:8000 -p 8082:8000 \
  -p 8083:8000 -p 8084:8000 -p 8085:8000 -p 8086:8000 -p 27017:27017
# then re-run each `podman run` above with --pod telcosphere-pod instead of --network ...
podman pod ps
```

## Base images

All backend services use `registry.access.redhat.com/ubi9/python-312`
(Red Hat Universal Base Image) and the frontend uses
`registry.access.redhat.com/ubi9/nginx-124` - both are the standard Red Hat
UBI images used with Podman, matching the Podman/Red Hat theme in the UI.

## Verified

Every service's `main.py` was smoke-tested end to end (health check + at
least one real endpoint) with a mocked MongoDB before being included here,
so the routing and imports are confirmed correct - only the actual
`podman build`/`podman run` execution itself hasn't been run (this
environment has no Podman/container runtime, only a plain Linux sandbox for
Python).

## Known simplifications (demo-grade, same spirit as the original monolith)

- All services share one Mongo database/connection string - a "real"
  microservice split would usually give each service its own database.
- No API gateway / ingress - the frontend calls each service's port
  directly. Fine for local `podman compose`; behind a real reverse proxy
  you'd map each service to a path or hostname instead of a port and update
  `SERVICE_PORTS`/`baseFor()` in `app.js` accordingly.
- `requirements-services.txt` is shared by 5 of the 6 services for
  simplicity; only `telcosphere-aiml` gets the heavier
  `requirements-aiml.txt` (scikit-learn/numpy/pandas).
